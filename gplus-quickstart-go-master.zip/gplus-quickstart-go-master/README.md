# Google+ Go Quick-Start

The documentation for this quick-start is maintained on developers.google.com.
Please see here for more information:
https://developers.google.com/+/quickstart/go
